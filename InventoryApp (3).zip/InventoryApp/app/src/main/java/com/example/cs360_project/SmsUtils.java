package com.example.cs360_project;

import android.content.Context;
import android.telephony.SmsManager;
import android.widget.Toast;


public final class SmsUtils {

    private SmsUtils() {
        // Utility class
    }

    public static boolean sendSms(Context context, String phoneNumber, String message) {
        if (!ValidationUtils.isValidPhoneNumber(phoneNumber)) {
            Toast.makeText(context, "No valid phone number saved for SMS.", Toast.LENGTH_SHORT).show();
            return false;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            return true;
        } catch (Exception e) {
            Toast.makeText(context, "Unable to send SMS right now.", Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}
