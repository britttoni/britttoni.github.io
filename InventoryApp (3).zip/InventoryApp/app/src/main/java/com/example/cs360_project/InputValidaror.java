package com.example.cs360_project;

public class InputValidaror {

    // Check if text is empty
    public static boolean isEmpty(String text) {
        return text == null || text.trim().isEmpty();
    }

    // Check if quantity is a valid positive number
    public static boolean isValidQuantity(String quantityText) {
        if (isEmpty(quantityText)) {
            return false;
        }

        try {
            int quantity = Integer.parseInt(quantityText.trim());
            return quantity > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Check if phone number looks valid
    public static boolean isValidPhoneNumber(String phoneNumber) {
        if (isEmpty(phoneNumber)) {
            return false;
        }

        String cleaned = phoneNumber.replaceAll("\\D", "");
        return cleaned.length() >= 10;
    }
}
