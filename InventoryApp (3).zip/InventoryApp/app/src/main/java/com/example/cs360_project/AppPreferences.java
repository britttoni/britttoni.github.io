package com.example.cs360_project;

import android.content.Context;
import android.content.SharedPreferences;

//Handles simple app settings like the SMS notification phone number.

public final class AppPreferences {

    private static final String PREFS_NAME = "inventory_app_prefs";
    private static final String KEY_NOTIFICATION_PHONE = "notification_phone";

    private AppPreferences() {
        // Utility class
    }

    public static void saveNotificationPhoneNumber(Context context, String phoneNumber) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        preferences.edit().putString(KEY_NOTIFICATION_PHONE, phoneNumber).apply();
    }

    public static String getNotificationPhoneNumber(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return preferences.getString(KEY_NOTIFICATION_PHONE, null);
    }

    public static boolean hasNotificationPhoneNumber(Context context) {
        return getNotificationPhoneNumber(context) != null;
    }
}
