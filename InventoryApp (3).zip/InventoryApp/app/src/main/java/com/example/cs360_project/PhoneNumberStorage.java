package com.example.cs360_project;

import android.content.Context;
import android.content.SharedPreferences;

public class PhoneNumberStorage {

    private static final String PREF_NAME = "InventoryPrefs";
    private static final String KEY_PHONE = "phone_number";

    // Save phone number in SharedPreferences
    public static void savePhoneNumber(Context context, String phoneNumber) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_PHONE, phoneNumber).apply();
    }

    // Get saved phone number
    public static String getPhoneNumber(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_PHONE, "");
    }
}