package com.example.cs360_project;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Handles SMS permission flow.

public class SmsPermissionActivity extends AppCompatActivity {

    public static final String EXTRA_PHONE_NUMBER = "extra_phone_number";
    private static final int SMS_PERMISSION_CODE = 100;
    private static final String WELCOME_MESSAGE = "Welcome! SMS notifications have been enabled.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        savePhoneNumberFromIntentIfPresent();
        setupButtons();
    }

    private void savePhoneNumberFromIntentIfPresent() {
        String phoneNumber = getIntent().getStringExtra(EXTRA_PHONE_NUMBER);

        if (ValidationUtils.isValidPhoneNumber(phoneNumber)) {
            AppPreferences.saveNotificationPhoneNumber(this, phoneNumber);
        }
    }

    private void setupButtons() {
        Button buttonRequest = findViewById(R.id.buttonRequestSmsPermission);
        Button buttonSkip = findViewById(R.id.buttonSkipSmsPermission);

        buttonRequest.setOnClickListener(v -> requestSmsPermission());
        buttonSkip.setOnClickListener(v -> goToMainActivity("SMS permission skipped. You can enable it later."));
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        } else {
            sendWelcomeSmsIfPossible();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendWelcomeSmsIfPossible();
            } else {
                goToMainActivity("Permission denied. No SMS notifications will be sent.");
            }
        }
    }

    private void sendWelcomeSmsIfPossible() {
        String phoneNumber = AppPreferences.getNotificationPhoneNumber(this);

        if (!AppPreferences.hasNotificationPhoneNumber(this)) {
            goToMainActivity("SMS permission granted, but no phone number is saved yet.");
            return;
        }

        boolean smsSent = SmsUtils.sendSms(this, phoneNumber, WELCOME_MESSAGE);

        if (smsSent) {
            goToMainActivity("Welcome SMS sent.");
        } else {
            goToMainActivity("Could not send welcome SMS.");
        }
    }

    private void goToMainActivity(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
