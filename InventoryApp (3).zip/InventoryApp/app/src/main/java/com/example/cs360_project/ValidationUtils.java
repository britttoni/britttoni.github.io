package com.example.cs360_project;

//validation helper used to keep Activities cleaner and easier to read.

public final class ValidationUtils {

    private ValidationUtils() {
        // Utility class
    }

    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static boolean isValidUsername(String username) {
        return !isBlank(username) && username.trim().length() >= 3;
    }

    public static boolean isValidPassword(String password) {
        return !isBlank(password) && password.trim().length() >= 4;
    }

    public static String normalizeItemName(String itemName) {
        return itemName == null ? "" : itemName.trim();
    }

    //Returns a positive integer if the text is valid, otherwise null.

    public static Integer parsePositiveQuantity(String quantityText) {
        if (isBlank(quantityText)) {
            return null;
        }

        try {
            int quantity = Integer.parseInt(quantityText.trim());
            return quantity > 0 ? quantity : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    //Very basic phone validation for digits with optional + sign.

    public static boolean isValidPhoneNumber(String phoneNumber) {
        if (isBlank(phoneNumber)) {
            return false;
        }

        String cleaned = phoneNumber.replaceAll("[^0-9+]", "");
        return cleaned.matches("^\\+?[0-9]{10,15}$");
    }
}
